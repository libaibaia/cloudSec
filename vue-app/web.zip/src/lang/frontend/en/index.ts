export default {
    'Steve Jobs': "Great art don't have to follow the trend, it alone can lead.-- Steve Jobs",
}
