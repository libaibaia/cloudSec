export default {
    'Please enter the correct mobile number': 'Please enter the correct mobile number',
    'Please enter the correct account': 'The account requires 3 to 15 characters and contains a-z A-Z 0-9 _',
    'Please enter the correct password': 'The password requires 6 to 32 characters and cannot contains & < > " \'',
    'Please enter the correct name': 'Please enter the correct name',
    'Content cannot be empty': 'The content cannot be blank',
    'Floating point number': ' Floating number',
    required: 'Required',
    'editor required': 'editor Required',
}
