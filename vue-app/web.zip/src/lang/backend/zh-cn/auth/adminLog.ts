export default {
    admin_id: '管理ID',
    username: '管理用户名',
    title: '标题',
    data: '请求数据',
    url: 'URL',
    ip: 'IP',
    useragent: 'UserAgent',
    createtime: '创建时间',
    'Operation administrator': '操作管理员',
    'Operator IP': '操作人IP',
    'Request data': '请求数据',
}
