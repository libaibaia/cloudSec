export default {
    GroupName: '组名',
    'Group name': 'secretKey',
    jurisdiction: '厂商',
}
