export default {
    'Rule name': 'Rule name',
    controller: 'Controller',
    'data sheet': 'Data table',
    'Data table primary key': 'Data table primary key',
    'Deleting monitoring': 'Delete monitoring',
    'The rule name helps to identify deleted data later': 'Rule names help to identify deleted data subsequently later.',
    'The data collection mechanism will monitor delete operations under this controller':
        'The data recycle mechanism will monitor the delete operations under this controller.',
    'Corresponding data sheet': 'Corresponding data sheet',
}
