const e={GroupName:"组名","Group name":"secretKey",jurisdiction:"厂商"};export{e as default};
