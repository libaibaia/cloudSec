import{f as o}from"./index-e5316322.js";function c(e,s,r){return o({url:e,method:s,data:r},{showSuccessMessage:!0})}export{c};
